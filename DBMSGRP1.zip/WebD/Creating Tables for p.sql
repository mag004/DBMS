use mydatabaseforproject;

CREATE TABLE IF NOT EXISTS users (
  id int unique NOT NULL AUTO_INCREMENT,
  phone  varchar(10) unique NOT NULL,
  name varchar(50) NOT NULL,
  username  varchar(25) NOT NULL,
  password varchar(100) NOT NULL,
  accountcreationtime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status varchar(1) NOT NULL DEFAULT '0',
  about varchar(30) NOT NULL DEFAULT 'Hey there!',
  PRIMARY KEY (id)
) ;

alter table users modify column phone varchar(10);

ALTER TABLE users
  MODIFY username varchar(25) unique NOT NULL;
  
-- select * from users;
SELECT * FROM users;


CREATE TABLE IF NOT EXISTS messages (
   mid int unique not null AUTO_INCREMENT, 
  msgtype varchar(4) NOT NULL, 
  msgbody varchar(1000) NOT NULL,
  msg_by int NOT NULL,
  msg_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (mid)
) ;

CREATE TABLE IF NOT EXISTS messagesSender (
	message_by int not null,
    mid int not null,
    primary key(message_by, mid),
	foreign key (message_by) references users(id),
	foreign key (mid) references messages(mid)
) ;

SELECT * FROM messages;



CREATE TABLE IF NOT EXISTS GrpMsg (
	mid int not null,
	g_id int not null,
    PRIMARY KEY(mid, g_id),
    foreign key (mid) references messages(mid)
) ;
SELECT * FROM GrpMsg;

CREATE TABLE IF NOT EXISTS GroupInfo (
	groupname varchar(50) unique not null,
    adminID int not null,    
    groupDescription varchar(300) not null,
    groupID int unique not null auto_increment,
    groupCreationTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	foreign key (adminID) references users(id),
	PRIMARY KEY(groupID)
) ;

CREATE TABLE IF NOT EXISTS UserMessages (
	message_to int not null,
    mid int not null,
    primary key(message_to, mid),
	foreign key (message_to) references users(id),
	foreign key (mid) references messages(mid)
);
 -- drop view userlist;
CREATE TABLE IF NOT EXISTS GroupMembers(
	uid int not null,
    gid int not null,
    primary key(uid, gid),
    foreign key(uid) references users(id),
    foreign key(gid) references groupinfo(groupID)
);

CREATE VIEW UserList AS
SELECT username FROM users;
-- //check from outside: self username == invalid search
-- 				User not found


CREATE VIEW groupMessage as select messages.mid, msgtype, msgbody, msg_by, msg_time, adminID, groupDescription, groupinfo.groupID, groupCreationTime 
from messages 
		left join grpmsg on messages.mid = grpmsg.mid
        left join groupinfo on grpmsg.g_id = groupinfo.groupID
        ;


CREATE VIEW GroupView AS
SELECT groupname, groupDescription FROM groupinfo;

select * from GroupList;


DROP table users;
-- REGISTRE PASS NOT MANDATORY


-- CREATE TABLE chat(
--     mid int not null,
-- 	msg_to int not null,
--     PRIMARY KEY(mid, msg_to),
--     foreign key (mid) references messages(mid)
-- );



