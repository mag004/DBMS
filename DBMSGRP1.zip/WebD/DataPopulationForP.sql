use mydatabaseforproject;


INSERT INTO users (phone, name, username, password, status, about)
VALUES 
		('9090909090', 'Bhagesh Gaur', 'bg_aur', 'hehe', 0, "only quantum"),
		('9090909091', 'Bhag Giri', 'b_giri', 'hehehe', 1, "quantized fun");
INSERT INTO users (phone, name, username, password, status, about)
VALUES 
		('9090909092', 'Darsh Parikh', 'dp', 'noice', 0, "my life is a lie"),
		('9090909093', 'Manas Agarwal', 'mag', 'toit', 1, "cses is life"),
		('9090909094', 'Samay Raina', '@sr', '#khash_mir', 0, "my gf - chess"),
		('9090909095', 'Rishabh Oberoi', 'o_r', '._.', 1, ".-."),
		('9090909096', 'Saumik Shashwat', '@ss', 'apple', 0, "apple is the worst"),
		('9090909097', 'James Potter', '#JP', 'james', 1, "mishchief managed"),
		('9090909098', 'Severus Snape', '$ss', 'severe', 0, "i love lily"),
		('9090909099', 'Harry Potter', '@HP', 'ron_bestie', 1, "3 lives baby!!!");
        
        
INSERT INTO messages (msgtype , msgbody, msg_by) 
VALUES 
		('text' , 'Hi', 1),
		('text' , 'hlw', 2),
		('text' , 'how are you?', 1),
		('text' , 'Fine. You?', 2),
		('text' , 'Fine', 1);

INSERT INTO UserMessages (mid,message_to)
VALUES (1, 2),
		(2, 1),
		(3, 2),
		(4, 1),
        (5, 2);
-- INSER-- T INTO UserMessages (mid,message_to)
-- VALUES         (6, 2);
--         
INSERT INTO GroupInfo (groupname, adminID, groupDescription)
VALUES ("College", "2", "For all the college people");

INSERT INTO GroupInfo (groupname, adminID, groupDescription)
VALUES ("Family", "2", "<333");

INSERT INTO GroupInfo (groupname, adminID, groupDescription)
VALUES ("Besties", "1", "ye dosti hum kabhi na todenge");

INSERT INTO GroupInfo (groupname, adminID, groupDescription)
VALUES ("DBMS Group", "4", "kaam karlo yaar");

INSERT INTO GroupInfo (groupname, adminID, groupDescription)
VALUES ("IIITD 24", "7", "4 saal sath");


INSERT INTO GroupMembers (uid, gid)
VALUES ("2", "1");

INSERT INTO GroupMembers (uid, gid)
VALUES ("1", "1");


INSERT INTO GroupMembers (uid, gid)
VALUES ("4", "1");

INSERT INTO GroupMembers (uid, gid)
VALUES ("7", "1");


INSERT INTO GroupMembers (uid, gid)
VALUES ("2", "2");

INSERT INTO GroupMembers (uid, gid)
VALUES ("9", "2");

INSERT INTO GroupMembers (uid, gid)
VALUES ("10", "2");


INSERT INTO GroupMembers (uid, gid)
VALUES ("1", "3");

INSERT INTO GroupMembers (uid, gid)
VALUES ("2", "3");

INSERT INTO GroupMembers (uid, gid)
VALUES ("7", "3");



INSERT INTO GroupMembers (uid, gid)
VALUES ("4", "4");

INSERT INTO GroupMembers (uid, gid)
VALUES ("1", "4");

INSERT INTO GroupMembers (uid, gid)
VALUES ("6", "4");
        
INSERT INTO GroupMembers (uid, gid)
VALUES ("7", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("1", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("2", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("3", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("4", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("5", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("6", "5");

INSERT INTO GroupMembers (uid, gid)
VALUES ("8", "5");        

INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "hellooo", "2");
INSERT INTO messagesSender (message_by, mid)
VALUES (2, 6);
INSERT INTO UserMessages (message_to, mid)
VALUES ("3", "1");

INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "hiii sup", "3");
INSERT INTO messagesSender (message_by, mid)
VALUES (3, 7);
INSERT INTO UserMessages (message_to, mid)
VALUES ("2", "2");

INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "how are you??", "3");
INSERT INTO messagesSender (message_by, mid)
VALUES (3, 8);
INSERT INTO UserMessages (message_to, mid)
VALUES ("2", "3");
INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "hey everyone!", "1");
INSERT INTO messagesSender (message_by, mid)
VALUES (1, 9);

INSERT INTO GrpMsg (mid, g_id)
VALUES ("4", "1");

INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "happy beginnings", "2");
INSERT INTO messagesSender (message_by, mid)
VALUES (2, 10);
INSERT INTO GrpMsg (mid, g_id)
VALUES ("5", "1");

INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "so excited to meet y'all!!", "7");
INSERT INTO messagesSender (message_by, mid)
VALUES (7, 11);
INSERT INTO GrpMsg (mid, g_id)
VALUES ("7", "1");

INSERT INTO messages (msgtype, msgbody, msg_by)
VALUES ("text", "ada lab karlo", "4");
INSERT INTO messagesSender (message_by, mid)
VALUES (4, 12);
INSERT INTO GrpMsg (mid, g_id)
VALUES ("7", "1");


