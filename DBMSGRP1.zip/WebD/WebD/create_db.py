import mysql.connector

mydb = mysql.connector.connect(
	host="127.0.0.1",
	user="root",
	password = "manasSQL005&",
	database="DBMS"
	)

my_cursor = mydb.cursor()
my_cursor.execute("Create Table User")
my_cursor.execute("SHOW TABLES")
for x in my_cursor:
    print(x)
# my_cursor.execute("CREATE DATABASE DBMS")

# my_cursor.execute("SHOW DATABASES")
# for db in my_cursor:
# 	print(db)