from pickle import FALSE
from flask import *
from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
from flask_mysqldb import MySQL
from wtforms import Form, StringField, IntegerField, BooleanField, TextAreaField, PasswordField, validators
from functools import wraps
from passlib.hash import sha256_crypt
import os
from wtforms.fields import EmailField

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Config MySQL
mysql = MySQL()
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '10#$estakirimael#7'
app.config['MYSQL_DB'] = 'mydatabaseforproject'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

# Initialize the app for use with this MySQL class
mysql.init_app(app)


# main = Flask(__name__)
# main.config['SQLALCHEMY_DATABASE_URI'] = "mysql://root:manasSQL005&@localhost/DBMS"
# main.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = FALSE
# db = SQLAlchemy(main)

@app.route('/')
def index():

  #  cur = mysql.connection.cursor()
  #  cur.execute("create table users(id int(11) not null auto_increment,username varchar(255) not null,password varchar(255) not null,primary key(id))")
    return render_template('intro.html')
    # return render_template('chats.html')


class RegisterForm(Form):
    name = StringField('Name', [validators.length(min=3, max=50), validators.input_required()], render_kw={'autofocus': True})
    username = StringField('Username', [validators.length(min=3, max=25), validators.input_required()])
    phone  = StringField('Phone', [validators.length(min=9, max=10), validators.input_required()])
    password = PasswordField('Password', [validators.length(min=3), validators.input_required()])
    about = StringField('About')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' :
      #   name = form.name.data
        print(form.name.data)
        print("working")
        name = form['name'].data
        phone = form.phone.data
        username = form.username.data
        password = sha256_crypt.encrypt(str(form.password.data))
        about = form.about.data
        # Create Cursor
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(phone, name, username, password, about) VALUES(%s, %s, %s, %s, %s)",
                    (phone, name, username, password, about))

        # Commit cursor
        mysql.connection.commit()

        # Close Connection
        cur.close()

        flash('You are now registered and can login', 'success')

        return redirect(url_for('index'))
#     elif request.method4 == 'GET':
#         print("bccc")  
#     print("outside loop")

    return render_template('register.html', form=form)



class LoginForm(Form):    # Create Message Form
    username = StringField('Username', [validators.length(min=1)], render_kw={'autofocus': True})
class MessageForm(Form):    # Create Message Form
    body = StringField('', [validators.length(min=1)], render_kw={'autofocus': True})
class ChatName(Form):
    chatname = StringField('chatname', [validators.length(min=1)], render_kw={'autofocus': True})
@app.route('/chats/<string:id>', methods=['POST', 'GET'])
def chats(id):
    # if 'lid' in session:
    # id = session['lid']
    # uid = session['uid']
    # Create cursor
    cur = mysql.connection.cursor()
    # Get message here
    cur.execute("SELECT * FROM messages WHERE (msg_by=%s) ", [int(id)])
    chats = cur.fetchall()
    # Close Connection
    print(chats)
    cur.close()
    return render_template('chats.html', chats=chats)
    # return redirect(url_for('login'))
# User Login
@app.route('/newChat', methods=['POST', 'GET'])
def newChat():
    # if 'lid' in session:
    # id = session['lid']
    # uid = session['uid']
    # Create cursor
    cur = mysql.connection.cursor()
    # Get message here
    cur.execute("SELECT * FROM users")
    chats = cur.fetchall()
    # Close Connection
    # print(chats)
    cur.close()
    return render_template('html.html', chats=chats)
@app.route('/ribbon/<string:id>', methods=['POST', 'GET'])
def ribbon(id):
    # if 'lid' in session:
    # id = session['lid']
    # uid = session['uid']
    # Create cursor
    cur = mysql.connection.cursor()
    # Get message here
    cur.execute("SELECT * FROM users")
    chats = cur.fetchall()
    # Close Connection
    # print(chats)
    cur.close()
    return render_template('html.html', chats=chats)
@app.route('/')
@app.route("/login", methods=['GET', 'POST'])
# def login():
#       msg = ''
#       form = LoginForm(request.form)
#       if request.method == 'POST' and form.validate():
#             # GEt user form
#             username = form.username.data
#             password = request.form['password']

#             # Create cursor
#             cur = mysql.connection.cursor()
            
#             cur.execute('SELECT * FROM users WHERE username = % s AND password = % s', (username, password, ))
#             account = cur.fetchone()
#             if account:
#                   session['loggedin'] = True
#                   session['id'] = account['id']
#                   session['username'] = account['username']
#                   msg = 'Logged in successfully !'
#                   return render_template('intro.html', msg = msg)
#             else:
#                   msg = 'Incorrect username / password !'
#       return render_template('login.html', msg = msg)





def login():
    form = LoginForm(request.form)
    if request.method == 'POST' and form.validate():
        # GEt user form
        username = form.username.data
        password_candidate = request.form['password']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get user by username
        result = cur.execute("SELECT * FROM users WHERE username=%s", [username])

        if result > 0:
            # Get stored value
            data = cur.fetchone()
            password = data['password']
            uid = data['id']
            name = data['name']

            # Compare password
            if sha256_crypt.verify(password_candidate, password):
                # passed
                session['logged_in'] = True
                session['uid'] = uid
                session['s_name'] = name
                x = '1'
                cur.execute("UPDATE users SET status=%s WHERE id=%s", (x, uid))
                flash('You are now logged in', 'success')

                # return redirect(url_for('chats',id=uid))
                return redirect(url_for('index'))

            else:
                flash('Incorrect password', 'danger')
                return render_template('login.html', form=form)

        else:
            flash('Username not found', 'danger')
            # Close connection
            cur.close()
            return render_template('login.html', form=form)
    return render_template('login.html', form=form)

      #       # Get user by username
      #       result = cur.execute("SELECT * FROM users WHERE username=%s", [username])

      #       if result > 0:
      #             # Get stored value
      #             data = cur.fetchone()
      #             password = data['password']
      #             uid = data['id']
      #             name = data['name']

      #             # Compare password
      #             if sha256_crypt.verify(password_candidate, password):
      #             # passed
      #             session['logged_in'] = True
      #             session['uid'] = uid
      #             session['s_name'] = name
      #             x = '1'
      #             cur.execute("UPDATE users SET online=%s WHERE id=%s", (x, uid))
      #             flash('You are now logged in', 'success')

      #             return redirect(url_for('index'))

      #             else:
      #             flash('Incorrect password', 'danger')
      #             return render_template('login.html', form=form)

      #       else:
      #             flash('Username not found', 'danger')
      #             # Close connection
      #             cur.close()
      #             return render_template('login.html', form=form)
      # return render_template('login.html', form=form)
@app.route('/messageWindow', methods=['GET', 'POST'])
def messageWindow():

    if request.method == 'POST':
        form = ChatName(request.form)
        cur = mysql.connection.cursor()
        chatname = form.chatname.data
        # chatname = request.form['chatname']
        # Get user by username
        print(chatname)
        cur.execute("SELECT * FROM users WHERE name=%s", [chatname])
        message = cur.fetchall
        cur.close()
        return render_template('msgWindow.html', message=message)

@app.route('/out')
def logout():
    if 'uid' in session:

        # Create cursor
        cur = mysql.connection.cursor()
        uid = session['uid']
        x = '0'
        cur.execute("UPDATE users SET status=%s WHERE id=%s", (x, uid))
        session.clear()
        flash('You are logged out', 'success')
        return redirect(url_for('index'))
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)

