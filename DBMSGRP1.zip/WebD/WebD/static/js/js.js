window.addEventListener('load', () => {
    const ribb = document.querySelector("#ribbon");

    const ribb_el = document.createElement("li");
    ribb_el.classList.add("clearfix rib_el")

    const name_el = document.createElement("div");
    name_el.classList.add("name");
    name_el.innerHTML = "Hello Name";

    ribb_el.appendChild(name_el);

    const status_el = document.createElement("div");
    status_el.classList.add("status");

    const status_dot = document.createElement("i");
    status_dot.classList.add("fa fa-circle offline");
    
    status_el.appendChild(status_dot);
    status_el.innerHTML = "offline";

    ribb_el.appendChild(status_el);
    ribb.appendChild(ribb_el);

})