use mydatabaseforproject;

-- select ifnull(SELECT username FROM userlist
-- where username == searched_uname && searched_uname != cur_uname, "No userfound");



-- Chat History of 2 users

SELECT * FROM  messages as M 
WHERE (((msg_by in (select id from users where phone = "9090909091")) AND (mid IN (Select mid from UserMessages where message_to in (select id from users where phone = "9090909090"))) ) OR ((msg_by in (select id from users where phone = "9090909090")) AND (mid IN (Select mid from UserMessages where message_to in (select id from users where phone = "9090909091")))) )
ORDER BY M.msg_time DESC;

-- SELECT msgbody FROM  messages 
-- WHERE ((msg_by = 2) AND (mid IN (Select mid from UserMessages where message_to = 1)) );

CREATE INDEX usermsg_ind
 ON UserMessages (mid, message_to);
 
 CREATE INDEX usermsg_ind
 ON UserMessages (mid, message_to);
 
  CREATE INDEX msg
 ON messages (mid, msg_by);
 
   CREATE INDEX usernames
 ON users (username);


-- CONVERSATION RIBBON

select DISTINCT * from users as U2
where U2.id IN (select message_to from UserMessages where mid in ( select mid from messages where msg_by in (select id from users where phone = "9090909090") ) OR U2.id in (select msg_by from messages where mid in (select mid from usermessages where usermessages.message_to in (select id from users where phone ="9090909090"))) );


select messages.msg_by, messages.msgbody, messages.mid, messages.msg_time, usermessages.message_to, users.username
FROM messages
INNER JOIN usermessages ON messages.mid = usermessages.mid
 INNER JOIN users ON usermessages.message_to = users.id
	WHERE messages.mid IN
		(SELECT mid
		 FROM messages
		 WHERE msg_by = 1)
  	ORDER BY messages.msg_time DESC
;

select msgbody from messages
where msgbody like '%hi%';

select count(*) from groupinfo;


SELECT * FROM messages 
where mid IN (Select s.mid from grpmsg s
) ;


SELECT * FROM messages 
where mid IN (Select s.mid from grpmsg s
) ;


-- select messages.msg_by, messages.msgbody, messages.mid, messages.msg_time, usermessages.message_to, users.username
-- FROM messages
-- INNER JOIN usermessages ON messages.mid = usermessages.mid
--  INNER JOIN users ON usermessages.message_to = users.id
-- 	WHERE messages.mid IN
-- 		(SELECT mid
-- 		 FROM messages
-- 		 WHERE msg_by = 1)
-- 		AND msg_by != 1
--   	ORDER BY messages.msg_time 
-- ;



-- DELIMITER $$
-- CREATE TRIGGER del_msg
--     BEFORE DELETE
--     ON messages FOR EACH ROW
--     BEGIN
-- 		DELETE FROM UserMessages WHERE messages.mid = UserMessages.mid; 
-- 	END$$
-- DELIMITER ;


-- drop trigger del_msg;

-- delete from messages where mid = 1;

-- select * from messages;

-- select * from UserMessages;

DELIMITER $$
CREATE TRIGGER del_msg
    after DELETE
    ON UserMessages FOR EACH ROW
    BEGIN
		DELETE FROM messages WHERE messages.mid=old.mid; 
	END$$
DELIMITER ;


drop trigger del_msg;

delete from UserMessages where mid = 2;

select * from messages
where mid in (select mid from grpmsg where g_id = 1 
					IN (select mid from messagesSender where msg_by = 1)
);

SELECT 
	*
FROM messages
LEFT JOIN UserMessages ON UserMessages.mid = messages.mid
LEFT JOIN GrpMsg ON GrpMsg.mid = UserMessages.mid
;


SELECT msgbody
FROM messages
WHERE mid>1
LIMIT 5;

-- count of messages by a particular user in a group.
Select COUNT(mid)
from GrpMsg
where mid in (select mid from messagesSender 
where message_by = 3) AND g_id = 1;

-- ALTER TABLE messages
-- ADD CONSTRAINT  
-- FOREIGN KEY () 
-- REFERENCES ChildTable (xyz) ON DELETE CASCADE 

